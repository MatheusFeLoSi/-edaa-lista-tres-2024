package Exercicio4;

import java.util.List;

public class Ordenador {
    
    public static void SelectionSort(List<String> listaDeNomes) {
        int n = listaDeNomes.size(); 

        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (listaDeNomes.get(j).length() < listaDeNomes.get(minIndex).length()) {
                    minIndex = j;
                }
            }
            
            String temp = listaDeNomes.get(minIndex);
            listaDeNomes.set(minIndex, listaDeNomes.get(i));
            listaDeNomes.set(i, temp);
        }
    }
}

