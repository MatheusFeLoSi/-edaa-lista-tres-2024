package Exercicio5;

public class Frase {
    
    private String frase;

    public Frase() {
    }

    public String getFrase() {
        return frase;
    }
    public void setFrase(String frase) {
        this.frase = frase;
    }  

    private int particionar(int inicio, int fim) {
        char[] array = frase.toCharArray();
        char pivo = array[fim];
        int i = inicio - 1;
        for (int j = inicio; j < fim; j++) {
            if (array[j] < pivo) {
                i++;
                char temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }
        char temp = array[i + 1];
        array[i + 1] = array[fim];
        array[fim] = temp;
        frase = new String(array);
        return i + 1;
    }

    public void quickSort(int inicio, int fim) {
        if (inicio < fim) {
            int indicePivo = particionar(inicio, fim);
            quickSort(inicio, indicePivo - 1);
            quickSort(indicePivo + 1, fim);
        }
    }
}
