package Exercicio2;

public class Ordenador {
    public static void insertionSort(String[] nomes) {
        int n = nomes.length; 
        
        for (int i = 1; i < n; ++i) {
            String key = nomes[i];
            int j = i -1;
        
            while (j >= 0 && nomes[j].compareTo(key) > 0) {
                nomes[j + 1] = nomes[j];
                j = j - 1;
            }
            nomes[j + 1] = key; 
        }
    }
}
